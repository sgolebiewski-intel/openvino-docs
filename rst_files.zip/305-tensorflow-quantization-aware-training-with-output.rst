Quantization Aware Training with NNCF, using TensorFlow Framework
=================================================================

The goal of this notebook to demonstrate how to use the Neural Network
Compression Framework `NNCF <https://github.com/openvinotoolkit/nncf>`__
8-bit quantization to optimize a TensorFlow model for inference with
OpenVINO™ Toolkit. The optimization process contains the following
steps: \* Transforming the original ``FP32`` model to ``INT8`` \* Using
fine-tuning to restore the accuracy. \* Exporting optimized and original
models to Frozen Graph and then to OpenVINO. \* Measuring and comparing
the performance of models.

For more advanced usage, refer to these
`examples <https://github.com/openvinotoolkit/nncf/tree/develop/examples>`__.

This tutorial uses the ResNet-18 model with Imagenette dataset.
Imagenette is a subset of 10 easily classified classes from the Imagenet
dataset. Using the smaller model and dataset will speed up training and
download time.

Imports and Settings
--------------------

Import NNCF and all auxiliary packages from your Python code. Set a name
for the model, input image size, used batch size, and the learning rate.
Also, define paths where Frozen Graph and OpenVINO IR versions of the
models will be stored.

   **NOTE**: All NNCF logging messages below ERROR level (INFO and
   WARNING) are disabled to simplify the tutorial. For production use,
   it is recommended to enable logging by removing
   ``set_log_level(logging.ERROR)``.

.. code:: ipython3

    from pathlib import Path
    import logging
    
    import tensorflow as tf
    import tensorflow_datasets as tfds
    from tensorflow.python.keras import layers
    from tensorflow.python.keras import models
    
    from nncf import NNCFConfig
    from nncf.tensorflow.helpers.model_creation import create_compressed_model
    from nncf.tensorflow.initialization import register_default_init_args
    from nncf.common.utils.logger import set_log_level
    
    set_log_level(logging.ERROR)
    
    MODEL_DIR = Path("model")
    OUTPUT_DIR = Path("output")
    MODEL_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    BASE_MODEL_NAME = "ResNet-18"
    
    fp32_h5_path = Path(MODEL_DIR / (BASE_MODEL_NAME + "_fp32")).with_suffix(".h5")
    fp32_sm_path = Path(OUTPUT_DIR / (BASE_MODEL_NAME + "_fp32"))
    fp32_ir_path = Path(OUTPUT_DIR / "saved_model").with_suffix(".xml")
    int8_pb_path = Path(OUTPUT_DIR / (BASE_MODEL_NAME + "_int8")).with_suffix(".pb")
    int8_pb_name = Path(BASE_MODEL_NAME + "_int8").with_suffix(".pb")
    int8_ir_path = int8_pb_path.with_suffix(".xml")
    
    BATCH_SIZE = 128
    IMG_SIZE = (64, 64)  # Default Imagenet image size
    NUM_CLASSES = 10  # For Imagenette dataset
    
    LR = 1e-5
    
    MEAN_RGB = (0.485 * 255, 0.456 * 255, 0.406 * 255)  # From Imagenet dataset
    STDDEV_RGB = (0.229 * 255, 0.224 * 255, 0.225 * 255)  # From Imagenet dataset
    
    fp32_pth_url = "https://storage.openvinotoolkit.org/repositories/nncf/openvino_notebook_ckpts/305_resnet18_imagenette_fp32_v1.h5"
    _ = tf.keras.utils.get_file(fp32_h5_path.resolve(), fp32_pth_url)
    print(f'Absolute path where the model weights are saved:\n {fp32_h5_path.resolve()}')


.. parsed-literal::

    Downloading data from https://storage.openvinotoolkit.org/repositories/nncf/openvino_notebook_ckpts/305_resnet18_imagenette_fp32_v1.h5
    134610944/134604992 [==============================] - 4s 0us/step
    Absolute path where the model weights are saved:
     /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/model/ResNet-18_fp32.h5


Dataset Preprocessing
---------------------

Download and prepare Imagenette 160px dataset. - Number of classes: 10 -
Download size: 94.18 MiB \| Split \| Examples \| \|————–|———-\| \|
‘train’ \| 12,894 \| \| ‘validation’ \| 500 \|

.. code:: ipython3

    datasets, datasets_info = tfds.load('imagenette/160px', shuffle_files=True, as_supervised=True, with_info=True,
                                        read_config=tfds.ReadConfig(shuffle_seed=0))
    train_dataset, validation_dataset = datasets['train'], datasets['validation']
    fig = tfds.show_examples(train_dataset, datasets_info)



.. image:: 305-tensorflow-quantization-aware-training-with-output_files/305-tensorflow-quantization-aware-training-with-output_4_0.png


.. code:: ipython3

    def preprocessing(image, label):
        image = tf.image.resize(image, IMG_SIZE)
        image = image - MEAN_RGB
        image = image / STDDEV_RGB
        label = tf.one_hot(label, NUM_CLASSES)
        return image, label
    
    
    train_dataset = (train_dataset.map(preprocessing, num_parallel_calls=tf.data.experimental.AUTOTUNE)
                                  .batch(BATCH_SIZE)
                                  .prefetch(tf.data.experimental.AUTOTUNE))
    
    validation_dataset = (validation_dataset.map(preprocessing, num_parallel_calls=tf.data.experimental.AUTOTUNE)
                                            .batch(BATCH_SIZE)
                                            .prefetch(tf.data.experimental.AUTOTUNE))

Define a Floating-Point Model
-----------------------------

.. code:: ipython3

    def residual_conv_block(filters, stage, block, strides=(1, 1), cut='pre'):
        def layer(input_tensor):
            x = layers.BatchNormalization(epsilon=2e-5)(input_tensor)
            x = layers.Activation('relu')(x)
    
            # Defining shortcut connection.
            if cut == 'pre':
                shortcut = input_tensor
            elif cut == 'post':
                shortcut = layers.Conv2D(filters, (1, 1), strides=strides, kernel_initializer='he_uniform', 
                                         use_bias=False)(x)
    
            # Continue with convolution layers.
            x = layers.ZeroPadding2D(padding=(1, 1))(x)
            x = layers.Conv2D(filters, (3, 3), strides=strides, kernel_initializer='he_uniform', use_bias=False)(x)
    
            x = layers.BatchNormalization(epsilon=2e-5)(x)
            x = layers.Activation('relu')(x)
            x = layers.ZeroPadding2D(padding=(1, 1))(x)
            x = layers.Conv2D(filters, (3, 3), kernel_initializer='he_uniform', use_bias=False)(x)
    
            # Add residual connection.
            x = layers.Add()([x, shortcut])
            return x
    
        return layer
    
    
    def ResNet18(input_shape=None):
        """Instantiates the ResNet18 architecture."""
        img_input = layers.Input(shape=input_shape, name='data')
    
        # ResNet18 bottom
        x = layers.BatchNormalization(epsilon=2e-5, scale=False)(img_input)
        x = layers.ZeroPadding2D(padding=(3, 3))(x)
        x = layers.Conv2D(64, (7, 7), strides=(2, 2), kernel_initializer='he_uniform', use_bias=False)(x)
        x = layers.BatchNormalization(epsilon=2e-5)(x)
        x = layers.Activation('relu')(x)
        x = layers.ZeroPadding2D(padding=(1, 1))(x)
        x = layers.MaxPooling2D((3, 3), strides=(2, 2), padding='valid')(x)
    
        # ResNet18 body
        repetitions = (2, 2, 2, 2)
        for stage, rep in enumerate(repetitions):
            for block in range(rep):
                filters = 64 * (2 ** stage)
                if block == 0 and stage == 0:
                    x = residual_conv_block(filters, stage, block, strides=(1, 1), cut='post')(x)
                elif block == 0:
                    x = residual_conv_block(filters, stage, block, strides=(2, 2), cut='post')(x)
                else:
                    x = residual_conv_block(filters, stage, block, strides=(1, 1), cut='pre')(x)
        x = layers.BatchNormalization(epsilon=2e-5)(x)
        x = layers.Activation('relu')(x)
    
        # ResNet18 top
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Dense(NUM_CLASSES)(x)
        x = layers.Activation('softmax')(x)
    
        # Create the model.
        model = models.Model(img_input, x)
    
        return model

.. code:: ipython3

    IMG_SHAPE = IMG_SIZE + (3,)
    model = ResNet18(input_shape=IMG_SHAPE)

Pre-train a Floating-Point Model
--------------------------------

Using NNCF for model compression assumes that the user has a pre-trained
model and a training pipeline.

   **NOTE** For the sake of simplicity of the tutorial, it is
   recommended to skip ``FP32`` model training and load the weights that
   are provided.

.. code:: ipython3

    # Load the floating-point weights.
    model.load_weights(fp32_h5_path)
    
    # Compile the floating-point model.
    model.compile(loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1),
                  metrics=[tf.keras.metrics.CategoricalAccuracy(name='acc@1')])
    
    # Validate the floating-point model.
    test_loss, acc_fp32 = model.evaluate(validation_dataset,
                                         callbacks=tf.keras.callbacks.ProgbarLogger(stateful_metrics=['acc@1']))
    print(f"\nAccuracy of FP32 model: {acc_fp32:.3f}")


.. parsed-literal::

    4/4 [==============================] - 1s 136ms/sample - loss: 0.9807 - acc@1: 0.8220
    
    Accuracy of FP32 model: 0.822


Save the floating-point model to the saved model, which will be later
used for conversion to OpenVINO IR and further performance measurement.

.. code:: ipython3

    model.save(fp32_sm_path)
    print(f'Absolute path where the model is saved:\n {fp32_sm_path.resolve()}')


.. parsed-literal::

    INFO:tensorflow:Assets written to: output/ResNet-18_fp32/assets


.. parsed-literal::

    /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/.venv/lib/python3.8/site-packages/tensorflow/python/keras/utils/generic_utils.py:494: CustomMaskWarning: Custom mask layers require a config and must override get_config. When loading, the custom mask layer must be passed to the custom_objects argument.
      warnings.warn('Custom mask layers require a config and must override '
    INFO:tensorflow:Assets written to: output/ResNet-18_fp32/assets


.. parsed-literal::

    Absolute path where the model is saved:
     /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/ResNet-18_fp32


Create and Initialize Quantization
----------------------------------

NNCF enables compression-aware training by integrating into regular
training pipelines. The framework is designed so that modifications to
your original training code are minor. Quantization is the simplest
scenario and requires only 3 modifications.

1. Configure NNCF parameters to specify compression

.. code:: ipython3

    nncf_config_dict = {
        "input_info": {"sample_size": [1, 3] + list(IMG_SIZE)},
        "log_dir": str(OUTPUT_DIR),  # The log directory for NNCF-specific logging outputs.
        "compression": {
            "algorithm": "quantization",  # Specify the algorithm here.
        },
    }
    nncf_config = NNCFConfig.from_dict(nncf_config_dict)

2. Provide a data loader to initialize the values of quantization ranges
   and determine which activation should be signed or unsigned from the
   collected statistics, using a given number of samples.

.. code:: ipython3

    nncf_config = register_default_init_args(nncf_config=nncf_config,
                                             data_loader=train_dataset,
                                             batch_size=BATCH_SIZE)

3. Create a wrapped model ready for compression fine-tuning from a
   pre-trained ``FP32`` model and a configuration object.

.. code:: ipython3

    compression_ctrl, model = create_compressed_model(model, nncf_config)

Evaluate the new model on the validation set after initialization of
quantization. The accuracy should be not far from the accuracy of the
floating-point ``FP32`` model for a simple case like the one being
demonstrated here.

.. code:: ipython3

    # Compile the INT8 model.
    model.compile(optimizer=tf.keras.optimizers.Adam(lr=LR),
                  loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1),
                  metrics=[tf.keras.metrics.CategoricalAccuracy(name='acc@1')])
    
    # Validate the INT8 model.
    test_loss, test_acc = model.evaluate(validation_dataset,
                                         callbacks=tf.keras.callbacks.ProgbarLogger(stateful_metrics=['acc@1']))
    print(f"\nAccuracy of INT8 model after initialization: {test_acc:.3f}")


.. parsed-literal::

    /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/.venv/lib/python3.8/site-packages/tensorflow/python/keras/optimizer_v2/optimizer_v2.py:374: UserWarning: The `lr` argument is deprecated, use `learning_rate` instead.
      warnings.warn(


.. parsed-literal::

    4/4 [==============================] - 1s 216ms/sample - loss: 0.9786 - acc@1: 0.8160
    
    Accuracy of INT8 model after initialization: 0.816


Fine-tune the Compressed Model
------------------------------

At this step, a regular fine-tuning process is applied to further
improve quantized model accuracy. Normally, several epochs of tuning are
required with a small learning rate, the same that is usually used at
the end of the training of the original model. No other changes in the
training pipeline are required. Here is a simple example.

.. code:: ipython3

    # Train the INT8 model.
    model.fit(train_dataset,
              epochs=2)
    
    # Validate the INT8 model.
    test_loss, acc_int8 = model.evaluate(validation_dataset,
                                         callbacks=tf.keras.callbacks.ProgbarLogger(stateful_metrics=['acc@1']))
    print(f"\nAccuracy of INT8 model after fine-tuning: {acc_int8:.3f}")
    print(f"\nAccuracy drop of tuned INT8 model over pre-trained FP32 model: {acc_fp32 - acc_int8:.3f}")


.. parsed-literal::

    Epoch 1/2
    101/101 [==============================] - 95s 913ms/step - loss: 0.7137 - acc@1: 0.9299
    Epoch 2/2
    101/101 [==============================] - 92s 914ms/step - loss: 0.6805 - acc@1: 0.9502
    4/4 [==============================] - 0s 76ms/sample - loss: 0.9769 - acc@1: 0.8140
    
    Accuracy of INT8 model after fine-tuning: 0.814
    
    Accuracy drop of tuned INT8 model over pre-trained FP32 model: 0.008


Save the ``INT8`` model to the frozen graph (saved model does not work
with quantized model for now). Frozen graph will be later used for
conversion to OpenVINO IR and further performance measurement.

.. code:: ipython3

    compression_ctrl.export_model(int8_pb_path, 'frozen_graph')
    print(f'Absolute path where the int8 model is saved:\n {int8_pb_path.resolve()}')


.. parsed-literal::

    Absolute path where the int8 model is saved:
     /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/ResNet-18_int8.pb


Export Frozen Graph Models to OpenVINO Intermediate Representation (IR)
-----------------------------------------------------------------------

Use Model Optimizer to convert the Saved Model and Frozen Graph models
to OpenVINO IR. The models are saved to the current directory.

For more information about Model Optimizer, see the `Model Optimizer
Developer
Guide <https://docs.openvino.ai/latest/openvino_docs_MO_DG_Deep_Learning_Model_Optimizer_DevGuide.html>`__.

Executing this command may take a while. There may be some errors or
warnings in the output. When Model Optimization successfully exports to
OpenVINO IR, the last lines of the output will include:
``[ SUCCESS ] Generated IR version 10 model``

.. code:: ipython3

    !mo --framework=tf --input_shape=[1,64,64,3] --input=data --saved_model_dir=$fp32_sm_path --output_dir=$OUTPUT_DIR


.. parsed-literal::

    Model Optimizer arguments:
    Common parameters:
    	- Path to the Input Model: 	None
    	- Path for generated IR: 	/opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output
    	- IR output name: 	saved_model
    	- Log level: 	ERROR
    	- Batch: 	Not specified, inherited from the model
    	- Input layers: 	data
    	- Output layers: 	Not specified, inherited from the model
    	- Input shapes: 	[1,64,64,3]
    	- Source layout: 	Not specified
    	- Target layout: 	Not specified
    	- Layout: 	Not specified
    	- Mean values: 	Not specified
    	- Scale values: 	Not specified
    	- Scale factor: 	Not specified
    	- Precision of IR: 	FP32
    	- Enable fusing: 	True
    	- User transformations: 	Not specified
    	- Reverse input channels: 	False
    	- Enable IR generation for fixed input shape: 	False
    	- Use the transformations config file: 	None
    Advanced parameters:
    	- Force the usage of legacy Frontend of Model Optimizer for model conversion into IR: 	False
    	- Force the usage of new Frontend of Model Optimizer for model conversion into IR: 	False
    TensorFlow specific parameters:
    	- Input model in text protobuf format: 	False
    	- Path to model dump for TensorBoard: 	None
    	- List of shared libraries with TensorFlow custom layers implementation: 	None
    	- Update the configuration file with input/output node names: 	None
    	- Use configuration file used to generate the model with Object Detection API: 	None
    	- Use the config file: 	None
    OpenVINO runtime found in: 	/opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/.venv/lib/python3.8/site-packages/openvino
    OpenVINO runtime version: 	2022.1.0-7019-cdb9bec7210-releases/2022/1
    Model Optimizer version: 	2022.1.0-7019-cdb9bec7210-releases/2022/1
    [ SUCCESS ] Generated IR version 11 model.
    [ SUCCESS ] XML file: /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/saved_model.xml
    [ SUCCESS ] BIN file: /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/saved_model.bin
    [ SUCCESS ] Total execution time: 9.93 seconds. 
    [ SUCCESS ] Memory consumed: 1086 MB. 
    It's been a while, check for a new version of Intel(R) Distribution of OpenVINO(TM) toolkit here https://software.intel.com/content/www/us/en/develop/tools/openvino-toolkit/download.html?cid=other&source=prod&campid=ww_2022_bu_IOTG_OpenVINO-2022-1&content=upg_all&medium=organic or on the GitHub*
    [ INFO ] The model was converted to IR v11, the latest model format that corresponds to the source DL framework input/output format. While IR v11 is backwards compatible with OpenVINO Inference Engine API v1.0, please use API v2.0 (as of 2022.1) to take advantage of the latest improvements in IR v11.
    Find more information about API v2.0 and IR v11 at https://docs.openvino.ai


.. code:: ipython3

    !mo --framework=tf --input_shape=[1,64,64,3] --input=Placeholder --input_model=$int8_pb_path --output_dir=$OUTPUT_DIR


.. parsed-literal::

    Model Optimizer arguments:
    Common parameters:
    	- Path to the Input Model: 	/opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/ResNet-18_int8.pb
    	- Path for generated IR: 	/opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output
    	- IR output name: 	ResNet-18_int8
    	- Log level: 	ERROR
    	- Batch: 	Not specified, inherited from the model
    	- Input layers: 	Placeholder
    	- Output layers: 	Not specified, inherited from the model
    	- Input shapes: 	[1,64,64,3]
    	- Source layout: 	Not specified
    	- Target layout: 	Not specified
    	- Layout: 	Not specified
    	- Mean values: 	Not specified
    	- Scale values: 	Not specified
    	- Scale factor: 	Not specified
    	- Precision of IR: 	FP32
    	- Enable fusing: 	True
    	- User transformations: 	Not specified
    	- Reverse input channels: 	False
    	- Enable IR generation for fixed input shape: 	False
    	- Use the transformations config file: 	None
    Advanced parameters:
    	- Force the usage of legacy Frontend of Model Optimizer for model conversion into IR: 	False
    	- Force the usage of new Frontend of Model Optimizer for model conversion into IR: 	False
    TensorFlow specific parameters:
    	- Input model in text protobuf format: 	False
    	- Path to model dump for TensorBoard: 	None
    	- List of shared libraries with TensorFlow custom layers implementation: 	None
    	- Update the configuration file with input/output node names: 	None
    	- Use configuration file used to generate the model with Object Detection API: 	None
    	- Use the config file: 	None
    OpenVINO runtime found in: 	/opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/.venv/lib/python3.8/site-packages/openvino
    OpenVINO runtime version: 	2022.1.0-7019-cdb9bec7210-releases/2022/1
    Model Optimizer version: 	2022.1.0-7019-cdb9bec7210-releases/2022/1
    [ ERROR ]  Exception occurred during running replacer "REPLACEMENT_ID" (<class 'openvino.tools.mo.front.user_data_repack.UserDataRepack'>): No node with name Placeholder


Benchmark Model Performance by Computing Inference Time
-------------------------------------------------------

Finally, measure the inference performance of the ``FP32`` and ``INT8``
models, using `Benchmark
Tool <https://docs.openvino.ai/latest/openvino_inference_engine_tools_benchmark_tool_README.html>`__
- an inference performance measurement tool in OpenVINO. By default,
Benchmark Tool runs inference for 60 seconds in asynchronous mode on
CPU. It returns inference speed as latency (milliseconds per image) and
throughput (frames per second) values.

   **NOTE**: This notebook runs ``benchmark_app`` for 15 seconds to give
   a quick indication of performance. For more accurate performance, it
   is recommended to run ``benchmark_app`` in a terminal/command prompt
   after closing other applications. Run
   ``benchmark_app -m model.xml -d CPU`` to benchmark async inference on
   CPU for one minute. Change CPU to GPU to benchmark on GPU. Run
   ``benchmark_app --help`` to see an overview of all command-line
   options.

.. code:: ipython3

    def parse_benchmark_output(benchmark_output):
        parsed_output = [line for line in benchmark_output if not (line.startswith(r"[") or line.startswith("  ") or line == "")]
        print(*parsed_output, sep='\n')
    
    
    print('Benchmark FP32 model (IR)')
    benchmark_output = ! benchmark_app -m $fp32_ir_path -d CPU -api async -t 15
    parse_benchmark_output(benchmark_output)
    
    print('\nBenchmark INT8 model (IR)')
    benchmark_output = ! benchmark_app -m $int8_ir_path -d CPU -api async -t 15
    parse_benchmark_output(benchmark_output)


.. parsed-literal::

    Benchmark FP32 model (IR)
    Count:          35520 iterations
    Duration:       15003.99 ms
    Latency:
    Throughput: 2367.37 FPS
    
    Benchmark INT8 model (IR)
    Traceback (most recent call last):
    RuntimeError: Model file /opt/home/k8sworker/cibuilds/ov-notebook/OVNotebookOps-231/.workspace/scm/ov-notebook/notebooks/305-tensorflow-quantization-aware-training/output/ResNet-18_int8.xml cannot be opened!


Show CPU Information for reference.

.. code:: ipython3

    from openvino.runtime import Core
    
    ie = Core()
    ie.get_property('CPU', "FULL_DEVICE_NAME")




.. parsed-literal::

    'Intel(R) Core(TM) i9-10920X CPU @ 3.50GHz'


